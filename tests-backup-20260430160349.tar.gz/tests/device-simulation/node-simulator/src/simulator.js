const mqtt = require('mqtt')

/**
 * 温度模拟算法
 */
class TemperatureSimulator {
  constructor(targetTemp = 100, heatRate = 0.15, coolRate = 0.05) {
    this.current = 25.0
    this.target = targetTemp
    this.heatRate = heatRate
    this.coolRate = coolRate
    this.noiseLevel = 0.3
  }

  update(state) {
    const noise = (Math.random() - 0.5) * this.noiseLevel
    switch (state) {
      case 'PRE_DECOCTING':
      case 'FIRST_DECOCTING':
      case 'SECOND_DECOCTING':
        this.current += (this.target - this.current) * this.heatRate + noise
        break
      case 'SOAKING':
        this.current += (25 - this.current) * 0.02 + noise
        break
      case 'DRAINING':
      case 'PACKAGING':
        this.current += (60 - this.current) * this.coolRate + noise
        break
      case 'IDLE':
      case 'READY':
      case 'PAUSED':
      default:
        this.current += (25 - this.current) * 0.01 + noise
        break
    }
    return Math.max(20, Math.min(150, this.current))
  }

  setTarget(temp) {
    this.target = temp
  }
}

/**
 * 设备模拟器核心类
 */
class DeviceSimulator {
  constructor(options = {}) {
    this.deviceCode = options.deviceCode || 'EQ001'
    this.deviceType = options.deviceType || 'decoct'
    this.tenantId = options.tenantId || 'default'
    this.brokerUrl = options.brokerUrl || 'mqtt://127.0.0.1:1883'
    this.intervalMs = options.intervalMs || 5000

    this.state = this.deviceType === 'decoct' ? 'IDLE' : 'PACKER_IDLE'
    this.tempSim = new TemperatureSimulator(100)
    this.currentTemp = 25.0
    this.progressPercent = 0
    this.remainingTime = 0
    this.faultCode = null

    this.client = null
    this.timer = null
    this.stateTimer = null
    this.countdownTimer = null

    this.onStatusChange = options.onStatusChange || (() => {})
  }

  async start() {
    this.client = mqtt.connect(this.brokerUrl, {
      clientId: `sim-${this.deviceCode}-${Date.now()}`,
      reconnectPeriod: 5000,
      connectTimeout: 10000,
    })

    this.client.on('connect', () => {
      console.log(`[${this.deviceCode}] MQTT connected to ${this.brokerUrl}`)
      const cmdTopic = `/openygt/${this.tenantId}/${this.deviceCode}/command`
      this.client.subscribe(cmdTopic, (err) => {
        if (err) console.error(`[${this.deviceCode}] Subscribe error:`, err)
        else console.log(`[${this.deviceCode}] Subscribed to ${cmdTopic}`)
      })
      this.publish('online', '')
    })

    this.client.on('message', (topic, payload) => {
      this.handleCommand(payload.toString())
    })

    this.client.on('error', (err) => {
      console.error(`[${this.deviceCode}] MQTT error:`, err.message)
    })

    this.timer = setInterval(() => this.reportStatus(), this.intervalMs)
  }

  stop() {
    if (this.timer) clearInterval(this.timer)
    if (this.stateTimer) clearTimeout(this.stateTimer)
    if (this.countdownTimer) clearInterval(this.countdownTimer)
    if (this.client) {
      this.publish('offline', '')
      this.client.end()
    }
    console.log(`[${this.deviceCode}] Simulator stopped`)
  }

  publish(messageType, payload) {
    if (!this.client || !this.client.connected) return
    const topic = `/openygt/${this.tenantId}/${this.deviceCode}/${messageType}`
    this.client.publish(topic, typeof payload === 'string' ? payload : JSON.stringify(payload), { qos: 1 })
  }

  reportStatus() {
    this.currentTemp = this.tempSim.update(this.state)
    const payload = {
      status: this.state,
      detailStatus: this.state,
      currentTemp: parseFloat(this.currentTemp.toFixed(2)),
      progressPercent: this.progressPercent,
      remainingTime: this.remainingTime,
      faultCode: this.faultCode,
      timestamp: Date.now()
    }
    this.publish('status', payload)
  }

  handleCommand(raw) {
    let cmd
    try {
      cmd = JSON.parse(raw)
    } catch {
      cmd = { commandType: raw.trim() }
    }
    console.log(`[${this.deviceCode}] Received command:`, cmd.commandType)

    switch (cmd.commandType) {
      case 'START':
        this.transitionTo(this.deviceType === 'decoct' ? 'READY' : 'PACKER_READY')
        break
      case 'PAUSE':
        this.transitionTo('PAUSED')
        break
      case 'STOP':
        this.transitionTo(this.deviceType === 'decoct' ? 'IDLE' : 'PACKER_IDLE')
        break
      case 'EMERGENCY_STOP':
        this.transitionTo('FAULT')
        this.faultCode = 'E999-急停触发'
        break
      case 'RESUME':
        this.resumeAutoTransition()
        break
      default:
        console.log(`[${this.deviceCode}] Unknown command: ${cmd.commandType}`)
    }
  }

  transitionTo(newState) {
    const oldState = this.state
    this.state = newState
    this.progressPercent = 0
    this.onStatusChange(this.deviceCode, oldState, newState)
    console.log(`[${this.deviceCode}] ${oldState} -> ${newState}`)

    if (this.deviceType === 'decoct') {
      this.scheduleAutoTransition(newState)
    }
  }

  scheduleAutoTransition(state) {
    if (this.stateTimer) clearTimeout(this.stateTimer)
    if (this.countdownTimer) clearInterval(this.countdownTimer)

    const transitions = {
      'READY': { next: 'FILLING', delay: 5000 },
      'FILLING': { next: 'SOAKING', delay: 10000 },
      'SOAKING': { next: 'PRE_DECOCTING', delay: 15000 },
      'PRE_DECOCTING': { next: 'FIRST_DECOCTING', delay: 20000 },
      'FIRST_DECOCTING': { next: 'ADD_LATE', delay: 15000 },
      'ADD_LATE': { next: 'SECOND_DECOCTING', delay: 5000 },
      'SECOND_DECOCTING': { next: 'DRAINING', delay: 15000 },
      'DRAINING': { next: 'IDLE', delay: 10000 },
    }

    const t = transitions[state]
    if (t) {
      const totalSeconds = Math.floor(t.delay / 1000)
      this.remainingTime = totalSeconds
      this.countdownTimer = setInterval(() => {
        this.remainingTime = Math.max(0, this.remainingTime - 1)
        this.progressPercent = Math.min(100, Math.floor(
          (1 - this.remainingTime / totalSeconds) * 100
        ))
        if (this.remainingTime <= 0) clearInterval(this.countdownTimer)
      }, 1000)

      this.stateTimer = setTimeout(() => {
        if (this.countdownTimer) clearInterval(this.countdownTimer)
        this.transitionTo(t.next)
      }, t.delay)
    }
  }

  resumeAutoTransition() {
    if (this.state === 'PAUSED') {
      this.scheduleAutoTransition(this.state)
    }
  }

  injectFault(faultCode) {
    this.faultCode = faultCode
    this.transitionTo('FAULT')
    this.publish('fault', faultCode)
  }
}

module.exports = { DeviceSimulator, TemperatureSimulator }
