const { DeviceSimulator } = require('./simulator')

const args = require('yargs')
  .option('code', { alias: 'c', type: 'string', default: 'EQ001', description: '设备编码' })
  .option('type', { alias: 't', type: 'string', default: 'decoct', choices: ['decoct', 'pack'], description: '设备类型' })
  .option('broker', { alias: 'b', type: 'string', default: 'mqtt://127.0.0.1:1883', description: 'MQTT Broker URL' })
  .option('tenant', { type: 'string', default: 'default', description: '租户ID' })
  .option('interval', { alias: 'i', type: 'number', default: 5000, description: '状态上报间隔(ms)' })
  .option('target-temp', { type: 'number', default: 100, description: '目标温度(°C)' })
  .option('count', { alias: 'n', type: 'number', default: 1, description: '模拟设备数量' })
  .help()
  .argv

const simulators = []

function createSimulator(index) {
  const code = args.count > 1 ? `${args.code}-${index + 1}` : args.code
  const sim = new DeviceSimulator({
    deviceCode: code,
    deviceType: args.type,
    tenantId: args.tenant,
    brokerUrl: args.broker,
    intervalMs: args.interval,
    onStatusChange: (deviceCode, oldState, newState) => {
      // 可在此接入日志或外部通知
    }
  })
  sim.tempSim.setTarget(args.targetTemp)
  return sim
}

async function main() {
  console.log('╔══════════════════════════════════════════╗')
  console.log('║     OpenYGT 设备模拟器 (Node.js)         ║')
  console.log('╚══════════════════════════════════════════╝')
  console.log(`Broker:    ${args.broker}`)
  console.log(`Type:      ${args.type}`)
  console.log(`Count:     ${args.count}`)
  console.log(`Interval:  ${args.interval}ms`)
  console.log(`Target:    ${args.targetTemp}°C`)
  console.log('')

  for (let i = 0; i < args.count; i++) {
    const sim = createSimulator(i)
    simulators.push(sim)
    await sim.start()
  }

  console.log('\n按 Ctrl+C 停止模拟器\n')
}

process.on('SIGINT', () => {
  console.log('\n正在停止所有模拟器...')
  simulators.forEach(s => s.stop())
  setTimeout(() => process.exit(0), 1000)
})

main().catch(err => {
  console.error('启动失败:', err)
  process.exit(1)
})
