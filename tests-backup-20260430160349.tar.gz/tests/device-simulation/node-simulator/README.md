# OpenYGT 设备模拟器 (Node.js)

基于 mqtt.js 的煎药机/包装机 MQTT 设备模拟器，支持状态机自动推进和温度曲线模拟。

## 安装

```bash
cd tests/device-simulation/node-simulator
npm install
```

## 用法

### 单台煎药机模拟
```bash
npm start -- --code=EQ001 --type=decoct --broker=mqtt://127.0.0.1:1883
```

### 单台包装机模拟
```bash
npm start -- --code=PK001 --type=pack
```

### 批量模拟（3台煎药机）
```bash
npm start -- --code=EQ --type=decoct --count=3
```

### 自定义参数
```bash
npm start -- \
  --code=EQ001 \
  --type=decoct \
  --broker=mqtt://192.168.1.10:1883 \
  --target-temp=110 \
  --interval=3000
```

## 参数说明

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `--code, -c` | EQ001 | 设备编码 |
| `--type, -t` | decoct | 设备类型: decoct / pack |
| `--broker, -b` | mqtt://127.0.0.1:1883 | MQTT Broker |
| `--tenant` | default | 租户ID |
| `--interval, -i` | 5000 | 状态上报间隔(ms) |
| `--target-temp` | 100 | 目标温度(°C) |
| `--count, -n` | 1 | 模拟设备数量 |

## 状态机（煎药机）

```
IDLE → READY → FILLING → SOAKING → PRE_DECOCTING → FIRST_DECOCTING
                                                          ↓
IDLE ← DRAINING ← SECOND_DECOCTING ← ADD_LATE ←───────────┘
```

各阶段自动推进时间：
- READY → FILLING: 5s
- FILLING → SOAKING: 10s
- SOAKING → PRE_DECOCTING: 15s
- PRE_DECOCTING → FIRST_DECOCTING: 20s
- FIRST_DECOCTING → ADD_LATE: 15s
- ADD_LATE → SECOND_DECOCTING: 5s
- SECOND_DECOCTING → DRAINING: 15s
- DRAINING → IDLE: 10s

## Topic 格式

- 状态上报: `/openygt/{tenantId}/{deviceCode}/status`
- 心跳: `/openygt/{tenantId}/{deviceCode}/heartbeat`
- 故障: `/openygt/{tenantId}/{deviceCode}/fault`
- 上线: `/openygt/{tenantId}/{deviceCode}/online`
- 离线: `/openygt/{tenantId}/{deviceCode}/offline`
- 指令接收: `/openygt/{tenantId}/{deviceCode}/command`

## 支持的指令

- `START`: 启动设备
- `PAUSE`: 暂停
- `STOP`: 停止并回到空闲
- `EMERGENCY_STOP`: 急停（触发故障状态）
- `RESUME`: 恢复
